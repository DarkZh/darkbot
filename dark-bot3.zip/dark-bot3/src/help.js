const help = (prefix) => {
	return `
❉────────────────────────❉

BEM VINDO(A) AO MENU DO DARK BOT:

❉────────────────────────❉

          *Comandos para figurinhas* 

➸ *${prefix}sticker* ou *${prefix}stiker*

➸ *${prefix}sticker nobg* ou *${prefix}stiker nobg*

➸ *${prefix}toimg*

➸ *${prefix}tsticker* ou *${prefix}tstiker*

         *Comandos memes*

➸ *${prefix}meme*

➸ *${prefix}memeindo*

         *Outros comandos* 

➸ *${prefix}gtts* (pt) (txt)

➸ *${prefix}loli*

➸ *${prefix}nsfwloli*

➸ *${prefix}url2img*

➸ *${prefix}ocr*

➸ *${prefix}wait*

➸ *${prefix}setprefix*

         *Comandos de grupo* 

➸ *${prefix}linkgroup*

➸ *${prefix}tagall*

➸ *${prefix}simih*

          *comandos variados* 

➸ *${prefix}promote @*

➸ *${prefix}demote @*

➸ *${prefix}kick @*

➸ *${prefix}welcome 1*

➸ *${prefix}welcome 0*

➸ *${prefix}clearall* (deleta todos os chats do wpp do bot)

➸ *${prefix}listadmins (lista dos admins)*

➸ *${prefix}add (numero da pessoa)*

➸ *${prefix}tagall*



📍 TRADUZIDO E REMODELADO POR DARK 📍

}

exports.help = help


